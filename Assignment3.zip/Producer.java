public class Producer extends Thread
{
	//private static int count = 0;
	private MessageQueue queue = null;

	public Producer(MessageQueue queue)
	{
		this.queue = queue;
	}

	public void run()
	{
			queue.put(generateMessage0());
			queue.put(generateMessage1());
			queue.put(generateMessage2());
			queue.put(generateMessage3());

	}

	private synchronized String generateMessage0()
	{
		String apple = "Apple";

		return apple;
	}
	private synchronized String generateMessage1()
	{
	
		String orange = "Orange";

		return orange;
	}
	private synchronized String generateMessage2()
	{
		String grape = "Grape";

		return grape;
	}
	private synchronized String generateMessage3()
	{
		String watermelon = "Watermelon";

		return watermelon;
	}
}