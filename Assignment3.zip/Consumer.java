
public class Consumer extends Thread
{
	private MessageQueue queue = null;

	public Consumer(MessageQueue queue)
	{
		this.queue = queue;
	}

	public void run()
	{
		
			System.out.println("Customer 1 bought one " + queue.get() + ".");
			System.out.println("Customer 2 bought one " + queue.get() + ".");
			System.out.println("Customer 3 bought one " + queue.get() + ".");
			System.out.println("Customer 4 bought one " + queue.get() + ".");

		
	}
}